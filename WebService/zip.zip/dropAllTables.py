import DBManager

DBManager.DropAll()
